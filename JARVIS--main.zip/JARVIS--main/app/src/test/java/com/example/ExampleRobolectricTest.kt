package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.automation.ActionType
import com.example.automation.JarvisActionManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS AI", appName)
  }

  @Test
  fun `test whatsapp command handling`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val actionManager = JarvisActionManager(context)

    val result = actionManager.processCommand("whatsapp pe hello msg bhejo")
    assertTrue(result.handled)
    assertEquals(ActionType.WHATSAPP_MESSAGE, result.actionType)
  }

  @Test
  fun `test youtube and camera command handling`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val actionManager = JarvisActionManager(context)

    val ytResult = actionManager.processCommand("youtube kholo")
    assertTrue(ytResult.handled)
    assertEquals(ActionType.SEARCH_YOUTUBE, ytResult.actionType)

    val camResult = actionManager.processCommand("camera kholo")
    assertTrue(camResult.handled)
    assertEquals(ActionType.OPEN_CAMERA, camResult.actionType)
  }

  @Test
  fun `test math command handling`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val actionManager = JarvisActionManager(context)

    val mathResult = actionManager.processCommand("50 * 4")
    assertTrue(mathResult.handled)
    assertEquals(ActionType.MATH_CALCULATION, mathResult.actionType)
    assertTrue(mathResult.spokenResponse.contains("200"))
  }

  @Test
  fun `test wake word detection and command stripping`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val actionManager = JarvisActionManager(context)

    // Test pure wake word call
    val wakeOnlyResult = actionManager.processCommand("Hey Jarvis")
    assertTrue(wakeOnlyResult.handled)
    assertEquals(ActionType.WAKE_GREETING, wakeOnlyResult.actionType)

    // Test wake word prefix with command
    val wakeWithCommandResult = actionManager.processCommand("Hey Jarvis open camera")
    assertTrue(wakeWithCommandResult.handled)
    assertEquals(ActionType.OPEN_CAMERA, wakeWithCommandResult.actionType)
  }
}

