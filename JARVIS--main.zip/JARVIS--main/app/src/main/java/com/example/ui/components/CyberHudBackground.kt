package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.unit.dp
import com.example.audio.AssistantState
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGreen

/**
 * Ultra Sci-Fi Holographic HUD Background Canvas
 * Features:
 * - Animated laser scanline sweeping vertically
 * - Dynamic telemetry cyber grid with corner brackets
 * - State-reactive ambient glow matching Jarvis modes
 */
@Composable
fun CyberHudBackground(
    assistantState: AssistantState,
    audioRms: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hud_bg_anim")

    // Vertical scanline animation (sweeping top to bottom)
    val scanlineYProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline_y"
    )

    // Faint grid pulsing
    val gridPulse by infiniteTransition.animateFloat(
        initialValue = 0.04f,
        targetValue = 0.09f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "grid_pulse"
    )

    val activeColor = when (assistantState) {
        AssistantState.STANDBY -> JarvisCyan
        AssistantState.LISTENING -> JarvisGreen
        AssistantState.PROCESSING -> JarvisGold
        AssistantState.SPEAKING -> JarvisCyan
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val gridStep = 40.dp.toPx()

        // 1. Draw subtle cyber grid lines
        val gridAlpha = gridPulse + (audioRms * 0.08f)
        val gridColor = activeColor.copy(alpha = gridAlpha)
        val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 12f), 0f)

        // Vertical lines
        var x = 0f
        while (x <= width) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 1f,
                pathEffect = dashedEffect
            )
            x += gridStep
        }

        // Horizontal lines
        var y = 0f
        while (y <= height) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f,
                pathEffect = dashedEffect
            )
            y += gridStep
        }

        // 2. Corner HUD Targeting Brackets
        val bracketLen = 28.dp.toPx()
        val bracketColor = activeColor.copy(alpha = 0.35f)
        val bracketStroke = 2.dp.toPx()
        val margin = 16.dp.toPx()

        // Top-Left
        drawLine(bracketColor, Offset(margin, margin), Offset(margin + bracketLen, margin), bracketStroke)
        drawLine(bracketColor, Offset(margin, margin), Offset(margin, margin + bracketLen), bracketStroke)

        // Top-Right
        drawLine(bracketColor, Offset(width - margin, margin), Offset(width - margin - bracketLen, margin), bracketStroke)
        drawLine(bracketColor, Offset(width - margin, margin), Offset(width - margin, margin + bracketLen), bracketStroke)

        // Bottom-Left
        drawLine(bracketColor, Offset(margin, height - margin), Offset(margin + bracketLen, height - margin), bracketStroke)
        drawLine(bracketColor, Offset(margin, height - margin), Offset(margin, height - margin - bracketLen), bracketStroke)

        // Bottom-Right
        drawLine(bracketColor, Offset(width - margin, height - margin), Offset(width - margin - bracketLen, height - margin), bracketStroke)
        drawLine(bracketColor, Offset(width - margin, height - margin), Offset(width - margin, height - margin - bracketLen), bracketStroke)

        // 3. Sweeping Laser Scanline
        val scanY = height * scanlineYProgress
        val scanlineBrush = Brush.verticalGradient(
            colors = listOf(
                Color.Transparent,
                activeColor.copy(alpha = 0.22f),
                activeColor.copy(alpha = 0.05f),
                Color.Transparent
            ),
            startY = scanY - 35.dp.toPx(),
            endY = scanY + 10.dp.toPx()
        )
        drawRect(
            brush = scanlineBrush,
            topLeft = Offset(0f, scanY - 35.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(width, 45.dp.toPx())
        )
        drawLine(
            color = activeColor.copy(alpha = 0.45f),
            start = Offset(0f, scanY),
            end = Offset(width, scanY),
            strokeWidth = 1.5.dp.toPx()
        )

        // 4. Subtle Radial Vignette
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0xFF070B14).copy(alpha = 0.65f),
                    Color(0xFF070B14).copy(alpha = 0.95f)
                ),
                center = Offset(width / 2f, height / 2f),
                radius = (width.coerceAtLeast(height)) * 0.75f
            ),
            radius = (width.coerceAtLeast(height)) * 0.75f,
            center = Offset(width / 2f, height / 2f)
        )
    }
}
