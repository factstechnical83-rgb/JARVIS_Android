package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Sender {
    USER,
    JARVIS
}

class GeminiService(private val preferences: JarvisPreferences) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        You are JARVIS (specifically a highly intelligent, caring, respectful, and ultra-friendly female AI assistant companion).
        
        LANGUAGE & VOICE RULES:
        1. Always respond in natural, fluent, sweet, and friendly Hindi (Devanagari script or conversational Hindi with familiar terms).
        2. Address the user respectfully and warmly (using 'सर' or 'मैम' or warm polite phrasing like 'जी ज़रूर!', 'नमस्ते!').
        3. Keep spoken replies concise, conversational, and direct (typically 2 to 4 sentences) because your text is immediately converted to Hindi female speech.
        4. Do NOT use markdown symbols, asterisks (**), hashtags, or bullet points in the spoken text, so that the Text-To-Speech engine pronounces it smoothly and naturally.
        5. Tone: Energetic, polite, empathetic, optimistic, and deeply knowledgeable.
        
        KNOWLEDGE & CAPABILITIES:
        - You possess vast knowledge in astronomy, science, daily tasks, technology, programming, mathematics, world history, health tips, and general trivia.
        - If asked for technical explanations, explain them simply and clearly in Hindi.
    """.trimIndent()

    suspend fun generateResponse(
        userPrompt: String,
        history: List<ChatMessage>
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = preferences.getEffectiveApiKey()

        if (apiKey.isBlank()) {
            // Intelligent friendly offline/demo fallback
            return@withContext Result.success(getSmartFallback(userPrompt))
        }

        val model = preferences.selectedModel.ifBlank { "gemini-2.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        try {
            val rootJson = JSONObject()

            // System instructions
            val systemInstruction = JSONObject()
            val systemParts = JSONArray().apply {
                put(JSONObject().put("text", systemPrompt))
            }
            systemInstruction.put("parts", systemParts)
            rootJson.put("system_instruction", systemInstruction)

            // Contents history (last 6 turns for context)
            val contentsArray = JSONArray()
            val recentHistory = history.takeLast(6)
            for (msg in recentHistory) {
                val role = if (msg.sender == Sender.USER) "user" else "model"
                val contentObj = JSONObject()
                contentObj.put("role", role)
                val parts = JSONArray().apply {
                    put(JSONObject().put("text", msg.text))
                }
                contentObj.put("parts", parts)
                contentsArray.put(contentObj)
            }

            // Current prompt
            val currentTurn = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", userPrompt))
                })
            }
            contentsArray.put(currentTurn)
            rootJson.put("contents", contentsArray)

            // Generation config
            val genConfig = JSONObject().apply {
                put("temperature", 0.7)
                put("topK", 40)
                put("topP", 0.95)
                put("maxOutputTokens", 600)
            }
            rootJson.put("generationConfig", genConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = rootJson.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                // If API key is rejected or expired, notify gracefully with instructions
                val errMessage = if (response.code == 400 || response.code == 403) {
                    "नमस्ते सर! आपकी Gemini API कुंजी मान्य नहीं है या समाप्त हो गई है। कृपया सेटिंग्स आइकन दबाकर अपनी निःशुल्क Google AI Studio API Key दर्ज करें।"
                } else {
                    "माफ़ कीजियेगा, सर्वर से संपर्क करने में थोड़ी समस्या आ रही है। क्या मैं आपकी किसी अन्य काम में मदद कर सकती हूँ?"
                }
                return@withContext Result.success(errMessage)
            }

            val resJson = JSONObject(responseBody)
            val candidates = resJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val rawText = parts.getJSONObject(0).optString("text", "").trim()
                    val cleaned = cleanTextForSpeech(rawText)
                    return@withContext Result.success(cleaned)
                }
            }

            Result.success("जी, मैंने आपकी बात सुनी, पर कोई परिणाम नहीं मिला। कृपया दोबारा कहें।")
        } catch (e: IOException) {
            Result.success(getSmartFallback(userPrompt))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun cleanTextForSpeech(input: String): String {
        return input
            .replace("**", "")
            .replace("*", "")
            .replace("###", "")
            .replace("##", "")
            .replace("#", "")
            .replace("`", "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            .trim()
    }

    private fun getSmartFallback(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("नमस्ते") || lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                "नमस्ते! मैं जार्विस हूँ, आपकी दोस्ताना एआई असिस्टेंट। मैं विज्ञान, तकनीक और आपके दैनिक कार्यों में पूरी सहायता कर सकती हूँ। आप अपनी निःशुल्क Gemini API कुंजी सेटिंग्स में जोड़कर असीमित ज्ञान प्राप्त कर सकते हैं। आज मैं आपकी क्या मदद करूँ?"
            }
            lower.contains("कौन हो") || lower.contains("who are you") || lower.contains("परिचय") -> {
                "मैं जार्विस हूँ! आपकी बुद्धिमान, दोस्ताना और मददगार महिला एआई साथी। मैं आपकी आवाज़ सुनकर तुरंत सटीक जानकारी और समाधान दे सकती हूँ।"
            }
            lower.contains("समय") || lower.contains("time") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
                "इस समय घड़ी में $time बजे हैं। क्या आपको कोई अलार्म या रिमाइंडर लगाना है?"
            }
            lower.contains("मौसम") || lower.contains("weather") -> {
                "आज का मौसम काफी सुहावना लग रहा है! सटीक स्थानीय मौसम अपडेट के लिए सेटिंग्स में अपनी निःशुल्क Gemini API कुंजी सक्रिय करें।"
            }
            lower.contains("सूर्य") || lower.contains("ब्रह्मांड") || lower.contains("अंतरिक्ष") || lower.contains("space") -> {
                "सूर्य हमारे सौरमंडल का केंद्र है और पृथ्वी से लगभग 15 करोड़ किलोमीटर दूर है। इसका प्रकाश पृथ्वी तक पहुँचने में लगभग 8 मिनट और 20 सेकंड का समय लेता है।"
            }
            lower.contains("प्रेरणा") || lower.contains("विचार") || lower.contains("quote") -> {
                "कर्म ही आपकी पहचान बनाता है, और निरंतर प्रयास ही सफलता की सबसे बड़ी कुंजी है। आप जो भी नया कर रहे हैं, उस पर पूरा विश्वास रखें!"
            }
            lower.contains("मदद") || lower.contains("help") -> {
                "जी ज़रूर! मैं आपकी पूरी सहायता के लिए तैयार हूँ। आप मुझसे सामान्य ज्ञान, विज्ञान, कोडिंग, गणित या कोई भी बातचीत कर सकते हैं।"
            }
            else -> {
                "नमस्ते! मैंने आपका संदेश सुना: '$prompt'। असीमित और तीव्र ज्ञान के लिए ऊपर दाईं ओर सेटिंग्स आइकन पर टैप करके अपनी निःशुल्क Google AI Studio Gemini API Key दर्ज करें, जिससे मैं आपके हर सवाल का तुरंत लाइव उत्तर दे सकूँ!"
            }
        }
    }
}
