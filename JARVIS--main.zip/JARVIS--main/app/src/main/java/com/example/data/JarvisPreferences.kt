package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class JarvisPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_AUTO_LISTEN = "auto_listen_hands_free"
        private const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
        private const val KEY_VOICE_PITCH = "voice_pitch"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_FEMALE_VOICE_STYLE = "female_voice_style"
        private const val KEY_SELECTED_MODEL = "selected_gemini_model"
    }

    var customApiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value.trim()).apply()

    fun getEffectiveApiKey(): String {
        val custom = customApiKey
        if (custom.isNotBlank()) return custom
        return try {
            val key = BuildConfig.GEMINI_API_KEY.trim()
            if (key == "MY_GEMINI_API_KEY" || key.isEmpty()) "" else key
        } catch (_: Throwable) {
            ""
        }
    }

    var autoListenHandsFree: Boolean
        get() = prefs.getBoolean(KEY_AUTO_LISTEN, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_LISTEN, value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, value).apply()

    var femaleVoiceStyle: String
        get() = prefs.getString(KEY_FEMALE_VOICE_STYLE, "NATURAL_FEMALE") ?: "NATURAL_FEMALE"
        set(value) = prefs.edit().putString(KEY_FEMALE_VOICE_STYLE, value).apply()

    var voicePitch: Float
        get() = prefs.getFloat(KEY_VOICE_PITCH, 1.08f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_PITCH, value).apply()

    var voiceSpeed: Float
        get() = prefs.getFloat(KEY_VOICE_SPEED, 0.98f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_SPEED, value).apply()

    var selectedModel: String
        get() = prefs.getString(KEY_SELECTED_MODEL, "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(value) = prefs.edit().putString(KEY_SELECTED_MODEL, value).apply()
}
